﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProject
{

    internal enum MATCH_STATE
    {
        NOT_STARTED, IN_PROGRESS, FINISHED
    }
    internal class Match
    {
        private MATCH_STATE _state;
        public MATCH_STATE State { get { return _state; } set { _state = value; } }

        private IOpponent _opponent1;
        public IOpponent Opponent1
        {
            get
            {
                return _opponent1;
            }
            set
            {
                _opponent1 = value;
            }
        }

        private IOpponent _opponent2;
        public IOpponent Opponent2
        {
            get
            {
                return _opponent2;
            }
            set
            {
                _opponent2 = value;
            }
        }

        public Match() : this(null) { }
        public Match(IOpponent opponent1) : this(opponent1, null) { }
        // Designated Constructor
        public Match(IOpponent opponent1, IOpponent opponent2)
        {
            Opponent1 = opponent1;
            Opponent2 = opponent2;
        }

        override
        public string ToString()
        {
            return (Opponent1 == null?"No opponent1 set" : Opponent1.Name) + " vs " + (Opponent2 == null?"No opponent2 set" : Opponent2.Name) + " (" + State + ")";
        }
    }
}
