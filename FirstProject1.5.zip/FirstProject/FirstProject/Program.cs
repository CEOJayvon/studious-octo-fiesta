﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

namespace FirstProject
{
    public class Program()
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Match Manager!");
            MatchManager matchManager = new MatchManager();
            bool mainMenu = true;
            while(mainMenu)
            {
                Console.WriteLine("Main Menu\n");
                Console.WriteLine("1. Persons");
                Console.WriteLine("2. Teams");
                Console.WriteLine("3. Matches");
                Console.WriteLine("9. Quit");
                string mainMenuInput = Console.ReadLine();
                switch(mainMenuInput)
                {
                    case "1":
                        Console.WriteLine("-> Persons Menu\n");
                        PersonsMenu(matchManager);
                        break;
                    case "2":
                        Console.WriteLine("-> Teams Menu\n");
                        TeamsMenu(matchManager);
                        break;
                    case "3":
                        Console.WriteLine("-> Matches Menu\n");
                        break;
                    case "9":
                        mainMenu = false;
                        break;
                    default:
                        Console.WriteLine("*** Invalid Choice ***\n\n");
                        break;
                }
            }
            Console.WriteLine("Thank you for using our Match Manager.");
        }

        private static void PersonsMenu(MatchManager matchManager)
        {
            bool personsMenu = true;
            string firstName, lastName, newFirstName, newLastName, teamName;
            while (personsMenu)
            {
                Console.WriteLine("Persons Menu\n");
                Console.WriteLine("1. Create Person");
                Console.WriteLine("2. Change Person's name");
                Console.WriteLine("3. Add Person to Team");
                Console.WriteLine("4. Remove Person from Team");
                Console.WriteLine("5. List all persons");
                Console.WriteLine("9. Return");
                string personsMenuInput = Console.ReadLine();
                switch(personsMenuInput)
                {
                    case "1":
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        if(matchManager.CreatePerson(firstName, lastName))
                        {
                            Console.WriteLine("You successfully created a person.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error creating the person.");
                        }
                        break;
                    case "2":
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        Console.WriteLine("Enter firstname");
                        newFirstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        newLastName = Console.ReadLine();
                        if(matchManager.ChangePersonName(firstName, lastName, newFirstName, newLastName))
                        {
                            Console.WriteLine("You successfully change the person's name.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error changing the person's name.");
                        }
                        break;
                    case "3":
                        Console.WriteLine("Enter the team's name");
                        teamName = Console.ReadLine();
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        if(matchManager.AddPersonToTeam(teamName, firstName, lastName))
                        {
                            Console.WriteLine("You successfully added a person to the team.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error adding the person to the team.");
                        }
                        break;
                    case "4":
                        Console.WriteLine("Enter the team's name");
                        teamName = Console.ReadLine();
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        if (matchManager.RemovePersonFromTeam(teamName, firstName, lastName))
                        {
                            Console.WriteLine("You successfully removed a person from the team.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error removing the person from the team.");
                        }
                        break;
                    case "5":
                        matchManager.ListAllPersons();
                        break;
                    case "9":
                        personsMenu = false;
                        break;
                }
            }
        }

        private static void TeamsMenu(MatchManager matchManager)
        {
            bool teamsMenu = true;
            string firstName, lastName, teamName;
            while (teamsMenu)
            {
                Console.WriteLine("Teams Menu\n");
                Console.WriteLine("1. Create Team");
                Console.WriteLine("3. Add Person to Team");
                Console.WriteLine("4. Remove Person from Team");
                Console.WriteLine("5. List all teams");
                Console.WriteLine("6. List persons in a team");
                Console.WriteLine("9. Return");
                string teamsMenuInput = Console.ReadLine();
                switch (teamsMenuInput)
                {
                    case "1":
                        Console.WriteLine("Enter team's name");
                        teamName = Console.ReadLine();
                        if (matchManager.CreateTeam(teamName))
                        {
                            Console.WriteLine("You successfully created a team.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error creating the team.");
                        }
                        break;
                    case "3":
                        Console.WriteLine("Enter the team's name");
                        teamName = Console.ReadLine();
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        if (matchManager.AddPersonToTeam(teamName, firstName, lastName))
                        {
                            Console.WriteLine("You successfully added a person to the team.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error adding the person to the team.");
                        }
                        break;
                    case "4":
                        Console.WriteLine("Enter the team's name");
                        teamName = Console.ReadLine();
                        Console.WriteLine("Enter firstname");
                        firstName = Console.ReadLine();
                        Console.WriteLine("Enter lastname");
                        lastName = Console.ReadLine();
                        if (matchManager.RemovePersonFromTeam(teamName, firstName, lastName))
                        {
                            Console.WriteLine("You successfully removed a person from the team.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error removing the person from the team.");
                        }
                        break;
                    case "5":
                        matchManager.ListAllTeams();
                        break;
                    case "6":
                        Console.WriteLine("Enter the team's name");
                        teamName = Console.ReadLine();
                        if(matchManager.ListPersonsInTeam(teamName))
                        {
                            Console.WriteLine("Successfully printed roster.");
                        }
                        else
                        {
                            Console.WriteLine("There was an error printing the roster of the team.");
                        }
                            break;
                    case "9":
                        teamsMenu = false;
                        break;
                }
            }
        }
    }

}
