﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProject
{
    internal class Team : IOpponent
    {
        private string _name;
        public string Name { get { return _name; } set { _name = value; } }
        private List<Person> _members;

        public Team() : this("Nameless"){ }

        //Designated Constructor
        public Team(string name)
        {
            Name = name;
            _members = new List<Person>();
        }

        public bool Add(Person person)
        {
            _members.Add(person);
            return true;
        }

        public bool Remove(Person person)
        {
            return _members.Remove(person);
        }

        public string Roster
        {
            get
            {
                string output = string.Empty;
                foreach (Person person in _members)
                {
                    output += person.Name + "\n";
                }
                return output;
            }
        }
    }
}
