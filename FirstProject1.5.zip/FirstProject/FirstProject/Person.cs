﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProject
{
    internal class Person : IOpponent
    {
        private String _firstName;
        public String FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
                _firstName = Char.ToUpper(_firstName[0]) + _firstName.Substring(1);
            }
        }
        private String _lastName;
        public String LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = Char.ToUpper(value[0]) + value.Substring(1);
            }
        }

        public String NickName { get; set; }
        public String FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }

            set
            {
                string[] fullName = value.Split(' ');
                if(fullName.Length == 2 )
                {
                    FirstName = fullName[0];
                    LastName = fullName[1];
                }
            }
        }
        public Person() : this("No Last Name") { }

        public Person(String lastName) : this(lastName, "No First Name") { }

        // Designated Constructor
        public Person(String lastName, String firstName)
        {
            LastName = lastName;
            FirstName = firstName;
        }

        public string Name
        {
            get
            {
                return FullName;
            }
        }

        override
        public string ToString()
        {
            return LastName + ", " + FirstName;
        }
    }
}
