﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProject
{
    internal class MatchManager
    {
        private Dictionary<string, Person> _persons;
        private Dictionary<string, Team> _teams;
        private List<Match> _matches;

        public MatchManager()
        {
            _persons = new Dictionary<string, Person>();
            _teams = new Dictionary<string, Team>();
            _matches = new List<Match>();
        }

        public bool CreatePerson(string firstName, string lastName)
        {
            bool result = false;
            Person person = new Person(lastName, firstName);
            //_persons.Add(person.FullName, person);
            if (!_persons.ContainsKey(person.FullName))
            {
                _persons[person.FullName] = person;
                result = true;
            }
            return result;
        }

        public string AllPersonsList
        {
            get
            {
                string output = string.Empty;
                foreach (Person person in _persons.Values)
                {
                    output += person.FullName + "\n";
                }
                return output;
            }
        }
        public string AllTeamsList
        {
            get
            {
                string output = string.Empty;
                foreach(Team team in _teams.Values)
                {
                    output += team.Name + "\n";
                }
                return output;
            }
        }

        public bool ChangePersonName(string oldFirstName, string oldLastName, string newFirstName, string newLastName)
        {
            bool result = false;
            if(FindPerson(newFirstName, newLastName) == null)
            {
                Person person = FindPerson(oldFirstName, oldLastName);
                if (person != null)
                {
                    _persons.Remove(person.FullName);
                    person.FirstName = newFirstName;
                    person.LastName = newLastName;
                    _persons[person.FullName] = person;
                    //person.FullName = newFirstName + " " + newLastName;
                    result = true;
                }
            }
            return result;
        }

        public bool AddPersonToTeam(string teamName, string firstName, string lastName)
        {
            bool result = false;
            Team team = FindTeam(teamName);
            if(team != null)
            {
                Person person = FindPerson(firstName, lastName);
                if(person != null)
                {
                    team.Add(person);
                    result = true;
                }
            }
            return result;
        }

        public bool RemovePersonFromTeam(string teamName, string firstName, string lastName)
        {
            bool result = false;
            Team team = FindTeam(teamName);
            if(team != null)
            {
                Person person = FindPerson(firstName, lastName);
                if(person != null)
                {
                    result = team.Remove(person);
                }
            }
            return result;
        }

        public bool ListAllPersons()
        {
            Console.WriteLine("List of all persons\n" + AllPersonsList);
            return true;
        }

        public bool ListPersonsInTeam(string teamName)
        {
            bool result = false;
            Team team = FindTeam(teamName);
            if(team != null )
            {
                Console.WriteLine("List of person in " + teamName);
                Console.WriteLine(team.Roster);
                result = true;
            }
            return result;
        }

        private Person FindPerson(string firstName, string lastName)
        {
            Person person = null;
            _persons.TryGetValue(firstName + " " + lastName, out person);
            return person;
        }

        public bool CreateTeam(string teamName)
        {
            bool result = false;
            Team team = FindTeam(teamName);
            if(team == null)
            {
                team = new Team(teamName);
                _teams[team.Name] = team;
                result = true;
            }

            return result;
        }

        public bool ListAllTeams()
        {
            Console.WriteLine("List of all Teams\n" + AllTeamsList);
            return true;
        }

        private Team FindTeam(string teamName)
        {
            Team team = null;
            _teams.TryGetValue(teamName, out team);
            return team;
        }
    }
}
