import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestAlbum {
    @Test
    public void testAddTrack(){
        Album album = new Album("Album 1", "Artist 1", 2025);
        album.addTrack("Track 1", 1);
        album.addTrack("Track 2", 2);
        album.addTrack("Track 3", 3);
        assertEquals(album.getAllTracks().size(), 3);
    }

    @Test
    public void testGetTrack(){
        Album album = new Album("Album 1", "Artist 1", 2025);
        album.addTrack("Track 1", 1);
        album.addTrack("Track 2", 2);
        album.addTrack("Track 3", 3);
        assertEquals("Title: Track 1 -- Length: 1", album.getTrack(1).toString());
        assertEquals("Title: Track 2 -- Length: 2", album.getTrack(2).toString());
        assertEquals("Title: Track 3 -- Length: 3", album.getTrack(3).toString());
        assertEquals(null, album.getTrack(4));
    }
}
