package org.csu.cpsc;
import java.util.ArrayList;

public class Album implements AlbumInterface {
  private String albumName;
  private String artistName;
  private int yearofRelease;
  private ArrayList<Track> listofTracks;


  public Album(String albumName, String artistName,int yearofRelease){
    this.albumName = albumName;
    this.artistName = artistName;
    this.yearofRelease = yearofRelease;
    this.listofTracks = new ArrayList<>();
  }
      
  @Override
  public void addTrack(String Trackname,int trackLengthInSeconds){
    listofTracks.add(new Track(Trackname, trackLengthInSeconds));
  }

  @Override
  public Track getTrack(int number){
    if(number >= 0 && number < listofTracks.size()){
      return listofTracks.get(number);
    }
    return null;
  }
    
  @Override
  public ArrayList<Track> getAllTracks(){
    return listofTracks;
  }
  
  @Override 
  public String getAlbumDetails(){
    return albumName + " by: " + artistName + " (" + yearofRelease + ")";
  }
}
