package org.csu.cpsc;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Album albumOne = new Album("peanut butter jelly time", "Banana", 2005);
        albumOne.addTrack("Peanut", 360);
        albumOne.addTrack("Butter", 250);
        albumOne.addTrack("Jelly", 400);

        Album albumTwo = new Album("Im the one","Deftones", 1998);
        albumTwo.addTrack("Entombed", 500);
        albumTwo.addTrack("Beware",300);
        albumTwo.addTrack("Passenger", 200);

        Album albumThree = new Album("Dagestan","Sabrina", 2017);
        albumTwo.addTrack("Dagestan", 100);
        albumTwo.addTrack("Love",140);
        albumTwo.addTrack("River", 370);

        List<Album> albums = Arrays.asList(albumOne, albumTwo, albumThree);
        System.out.println("Which album would you like to play?: ");
        for (int i = 0; i < albums.size(); i++){
            System.out.println((i + 1) + ". " + albums.get(i).getAlbumDetails());
        }

        int option = scanner.nextInt() - 1;
        if (option < 0 || option >= albums.size()){
            System.out.println("Invalid option.");
            return;
        }
        MediaPlayer mediaPlayer = new MediaPlayer();
        mediaPlayer.loadAlbum(albums.get(option));

        boolean playing = true;
        while(playing){
            System.out.println("\nOptions: 1-Next, 2-Previous, 3-Shuffle, 4-Loop, 5-Exit");
            int choice = scanner.nextInt();
            if (choice == 1){
                System.out.println("Now playing: " + mediaPlayer.playNext());
            } else if (choice == 2) {
                System.out.println("Now Playing:" + mediaPlayer.playPrevious());
            } else if (choice == 3) {
                mediaPlayer.shuffle();
            } else if (choice == 4) {
                mediaPlayer.setLoop(!playing);
                System.out.println("playlist is now on loop");
            } else if (option == 5){
                playing = false;
            } else {
                System.out.println("Invalid choice. Select a valid option.");
            }
        }
        scanner.close();
        
    }
}