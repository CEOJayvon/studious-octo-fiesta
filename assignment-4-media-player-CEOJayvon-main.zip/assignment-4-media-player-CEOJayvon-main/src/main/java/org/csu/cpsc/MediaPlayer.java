package org.csu.cpsc;
import java.util.Arrays;
import java.util.Random;
import java.util.LinkedList;
import java.util.Stack;

public class MediaPlayer implements MediaPlayerInterface {
  
  private LinkedList<Track> playList;
  private Stack<Track> previousTrack;
  private boolean loop; 
  private Track currentTrack;

  public MediaPlayer(){
    this.playList = new LinkedList<>();
    this.previousTrack = new Stack<>();
    this.loop = false;
    this.currentTrack = null;
  }
  @Override
   public void loadAlbum(AlbumInterface album){
    this.playList = new LinkedList<>(album.getAllTracks());
    this.previousTrack.clear();
    if(playList.isEmpty()){
      this.currentTrack = null;
    } else{
      this.currentTrack = playList.getFirst();
    }
  }
  @Override
  public Track playNext(){
    if(playList.isEmpty()){
      return null;
    }
    if(currentTrack != null){
      previousTrack.push(currentTrack);
      playList.removeFirst();
    } 
    if(loop && playList.isEmpty()){
      playList.addAll(previousTrack);
      previousTrack.clear();
    }
    if(playList.isEmpty()){
      currentTrack = null;
    } else {
      currentTrack = playList.getFirst();
    }
    return currentTrack;
  }
  @Override 
  public Track playPrevious(){
    if(!previousTrack.isEmpty()){
      playList.addFirst(currentTrack);
      currentTrack = previousTrack.pop();
    }
    return currentTrack;
  }
  @Override
 public void shuffle(){
    Random playShuffle = new Random();
    Track[] musicList = playList.toArray(new Track[0]);
    for(int i = musicList.length - 1; i > 0; i--){
      int x = playShuffle.nextInt(i + 1);
      Track temp = musicList[i];
      musicList[i] = musicList[x];
      musicList[x] = temp;
    }
    playList.clear();
    playList.addAll(Arrays.asList(musicList));
  }
  @Override  
  public void setLoop(boolean loop){
    this.loop = loop;
  }
}
