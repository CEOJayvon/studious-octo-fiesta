package org.csu.cpsc;

public interface MediaPlayerInterface {
    void loadAlbum(AlbumInterface album);
    Track playNext();
    Track playPrevious();
    void shuffle();
    void setLoop(boolean loop);
}
