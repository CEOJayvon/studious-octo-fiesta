package org.csu.cpsc;
import java.util.List;

public interface AlbumInterface {
    void addTrack(String trackName, int trackLengthInSeconds);
    Track getTrack(int number);
    List<Track> getAllTracks();
    String getAlbumDetails();
}
