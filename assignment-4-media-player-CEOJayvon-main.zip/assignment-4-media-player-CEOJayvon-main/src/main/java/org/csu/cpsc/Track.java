package org.csu.cpsc;

public class Track {
    private String title;
    private int lengthInSeconds;

    public Track(String title, int lengthInSeconds){
        this.title = title;
        this.lengthInSeconds = lengthInSeconds;

    }
    public String getTitle(){
        return title;
    }
    public int getLengthInSeconds(){
        return lengthInSeconds;
    }

    public String toString(){
        int minutes = lengthInSeconds / 60;
        int seconds = lengthInSeconds % 60;
        return "Title: " + title + " -- Length: " + minutes + "minutes" + lengthInSeconds + "seconds";
    }
}
