# Programming Assignment: Media Player

The goal of this assignment is to create a function Media Player in Java. We will create the framework that could be expanded to function as a player. By using Objects, Lists, Stacks, and Queues, we will create the framework for a functional player. 

## Process

To complete this assignment, you will be creating a `MediaPlayer.java` that inherits from the `MediaPlayerInterface`, `Album.java` that inherits the `AlbumInterface`, and completing a `Main.java` that will handle the user input.  I have also provided a `Track` class that contains the details for the track. 

Each class is responsible for the following actions:
* `Track` - The `Track` class holds the details of the track including a `String` for the title of the track and an `int` for the length of the track in seconds called `lengthInSeconds`.
  * To update this class, update the `toString()` so when it prints the length of the song it prints in `Minutes:Seconds`.
* `AlbumInterface` - The `AlbumInterface` holds the details for the functions that need to be implemented in the `Album` class.
  * No changes need to be made to this interface
* `Album` - The `Album` class implements the Album Interface. The album class should contain a `List` of `Track` objects that are used in the album. Other functions are outlined in the Interface. 
  * Create the `Album` class and verify it implements the `AlbumInterface`.
  * Create private variables needed for the class including an album name, List of Track objects, artist name, and a year for the released date of the object.
  * Implement the functions from the interface. 
* `MediaPlayerInterface` - This class contains the function definitions for the Media Player. 
  * No changes need to be made to this interface.
* `MediaPlayer` - This class implements the `MediaPlayerInterface`. This class will contain the logic for being able to go to the next song, return to the previous song, loop the songs, and shuffle the songs in the playlist. 
  * Create the `MediaPlayer` class and verify it implements the `MediaPlayerInterface`.
  * Create the private variables needed to hold the playlist and the previous played songs. 
  * Implement the functions in the interface. 
  * For the loop feature, if loop is on, reload the queue with the same album. If it is false, then let it be empty
  * For the previous feature, keep track of the previous songs, do not empty the previous sounds, just keep track of them in the order they were played. If previous is selected, then that song is removed from previous.
* `Main` - The `Main` class will hold the user interface. The user interface will be text based. A user should be able to do the following  
  * Select an album. Create 3 albums in the Main the user can choose from. Prompt them to select which one they want to listen to. 
  * Go to the next song. 
  * Go to the previous song. 
  * Allow the user to shuffle the songs in the playlist.
  * Allow the user to turn the loop feature on and off. 


