import java.util.*;

public class WeightedGraph<E> {
    private Map<E, Map<E, Integer>> adjList;

    public WeightedGraph() {
        adjList = new HashMap<>();
    }

    public void addVertex(E vertex) {
        adjList.putIfAbsent(vertex, new HashMap<>());
    }

    public void addEdge(E sourceVertex, E destinationVertex, int weight) {
        addVertex(sourceVertex);
        addVertex(destinationVertex);
        adjList.get(sourceVertex).put(destinationVertex, weight);
        adjList.get(destinationVertex).put(sourceVertex, weight); // undirected
    }

    public boolean hasVertex(E vertex) {
        return adjList.containsKey(vertex);
    }

    public boolean hasEdge(E sourceVertex, E destinationVertex) {
        return adjList.containsKey(sourceVertex) &&
               adjList.get(sourceVertex).containsKey(destinationVertex);
    }

    public ArrayList<E> bfs(E startingVertex) {
        Queue<E> queue = new LinkedList<>();
        ArrayList<E> visited = new ArrayList<>();

        queue.add(startingVertex);
        visited.add(startingVertex);

        while (!queue.isEmpty()) {
            E current = queue.poll();

            for (E neighbor : adjList.get(current).keySet()) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }

        return visited;
    }

    public ArrayList<E> dfs(E startingVertex) {
        Stack<E> stack = new Stack<>();
        ArrayList<E> visited = new ArrayList<>();

        stack.push(startingVertex);

        while (!stack.isEmpty()) {
            E current = stack.pop();

            if (!visited.contains(current)) {
                visited.add(current);

                for (E neighbor : adjList.get(current).keySet()) {
                    if (!visited.contains(neighbor)) {
                        stack.push(neighbor);
                    }
                }
            }
        }

        return visited;
    }

    public boolean hasPath(E start, E end) {
        ArrayList<E> visited = new ArrayList<>();
        return dfsPathCheck(start, end, visited);
    }

    private boolean dfsPathCheck(E current, E target, ArrayList<E> visited) {
        if (current.equals(target)) return true;

        visited.add(current);

        for (E neighbor : adjList.get(current).keySet()) {
            if (!visited.contains(neighbor)) {
                if (dfsPathCheck(neighbor, target, visited)) {
                    return true;
                }
            }
        }

        return false;
    }

    public void printGraph() {
        for (E vertex : adjList.keySet()) {
            System.out.print(vertex + " -> ");
            for (Map.Entry<E, Integer> edge : adjList.get(vertex).entrySet()) {
                System.out.print(edge.getKey() + "(" + edge.getValue() + ") ");
            }
            System.out.println();
        }
    }
}
