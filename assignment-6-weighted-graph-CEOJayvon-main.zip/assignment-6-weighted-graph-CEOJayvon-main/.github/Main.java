public class Main {
    public static void main(String[] args) {
        WeightedGraph<String> graph = new WeightedGraph<>();

        // Add weighted edges
        graph.addEdge("A", "B", 3);
        graph.addEdge("A", "C", 5);
        graph.addEdge("B", "D", 2);
        graph.addEdge("C", "E", 4);
        graph.addEdge("D", "E", 1);
        graph.addEdge("E", "F", 6);

        // Print Graph
        graph.printGraph();

        // Run BFS and DFS from A, C, E
        System.out.println("BFS from A: " + graph.bfs("A"));
        System.out.println("DFS from A: " + graph.dfs("A"));

        System.out.println("BFS from C: " + graph.bfs("C"));
        System.out.println("DFS from C: " + graph.dfs("C"));

        System.out.println("BFS from E: " + graph.bfs("E"));
        System.out.println("DFS from E: " + graph.dfs("E"));

        // Path checks
        System.out.println("Is there a path from E to C? " + graph.hasPath("E", "C"));
        System.out.println("Is there a path from B to D? " + graph.hasPath("B", "D"));
        System.out.println("Is there a path from E to A? " + graph.hasPath("E", "A"));
    }
}
