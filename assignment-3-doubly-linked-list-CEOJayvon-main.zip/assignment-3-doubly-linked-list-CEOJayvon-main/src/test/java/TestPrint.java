import org.csu.cpsc.MyDoublyLinkedList;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestPrint {
    @Test
    public void testGetDataForward(){
        MyDoublyLinkedList<String> llist = new MyDoublyLinkedList<String>();
        llist.add("blue");
        llist.add("green");
        llist.add("yellow");
        assertEquals(llist.getFormatDataForward().trim(), "blue green yellow");
    }

    @Test
    public void testGetDataBackward(){
        MyDoublyLinkedList<String> llist = new MyDoublyLinkedList<String>();
        llist.add("blue");
        llist.add("green");
        llist.add("yellow");
        assertEquals(llist.getFormatDataBackward().trim(), "yellow green blue");
    }
}
