package org.csu.cpsc;

public interface ListInterface<E> {
    void add(int index, E element);
    boolean add(E element);
    boolean contains(Object o);
    E get(int index);
    int indexOf(Object o);
    int lastIndexOf(Object o);
    E remove(int index);
    boolean remove(Object o);
    int size();
}
