package org.csu.cpsc;

public class Main {
    public static void main(String[] args) {
        MyDoublyLinkedList<String> llist = new MyDoublyLinkedList<String>();
        llist.add("blue");
        llist.add("green");
        llist.add("yellow");

        System.out.println(llist.getFormatDataForward()); //blue green yellow
        System.out.println(llist.getFormatDataBackward()); //yellow green blue
    }
}