package org.csu.cpsc;

public class MyDoublyLinkedList<E> implements ListInterface<E> {
    private Node<E> head;
    private Node<E> tail;

    public MyDoublyLinkedList(){
        head = null;
        tail = null;
    }

    @Override
    public void add(int index, E element){
        if(index >= 0 && index <= size()){
            if(head == null || index == size()){
                add(element);
            }else if(index == 0){
                Node<E> currentNode = head;
                head = new Node<E>(element);
                head.next = currentNode;
                currentNode.prev = head;
            }else if(index > 0 && index <= size()){
                Node<E> currentNode = head;
                int position = 0;

                while(position < index-1){
                    position+=1;
                    currentNode = currentNode.next;
                }

                Node<E> newNode = new Node(element);
                newNode.next = currentNode.next;
                newNode.prev = currentNode;
                currentNode.next.prev = newNode;
                currentNode.next = newNode;
            }
        } else {
            throw new IndexOutOfBoundsException("Not a valid index");
        }


    }

    @Override
    public boolean add(E element){
        try{
            if(head==null){
                Node<E> node = new Node<E>(element);
                this.head = node;
                this.tail = node;
                return true;
            }else{
                //Node<E> currentNode = tail;
                Node<E> node = new Node<E>(element);
                tail.next = node;
                node.prev = tail;
                tail = node;
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    @Override
    public boolean contains(Object o) {
        int index = indexOf(o);
        if(index > -1){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public int indexOf(Object o){
        Node<E> currentNode = head;
        int index = 0;

        while(currentNode != null){
            if(currentNode.data.equals(o)){
                return index;
            }else{
                index++;
                currentNode = currentNode.next;
            }
        }

        return -1;
    }

    @Override
    public int lastIndexOf(Object o){
        Node<E> currentNode = tail;
        int index = size()-1;


        while(currentNode != null){
            if(currentNode.data.equals(o)){
                return index;
            }

            index--;
            currentNode = currentNode.prev;
        }

        return -1;
    }

    @Override
    public E get(int index){
        //verify a valid index
        if(index >= 0 && index < size()){
//            int position = 0;
//            Node<E> currentNode = head;
//
//            while(position < index){
//                currentNode = currentNode.next;
//                position++;
//            }
//
//            return currentNode.data;

            Node<E> currentNode = head;
            while(index > 0){
                currentNode = currentNode.next;
                index--;
            }

            return currentNode.data;
        }else{
            throw new IndexOutOfBoundsException("Index invalid at get()");
        }
    }

    @Override
    public E remove(int index){
        if(index >= 0 && index < size()){
            if(index == 0 && size() == 1){
                E returnVal = head.data;
                head = null;
                tail = null;
                return returnVal;
            } else if(index == 0){
                E returnVal = head.data;
                head = head.next;
                head.prev = null;
                return returnVal;
            }else if(index == size()-1){
                E returnVal = tail.data;
                tail = tail.prev;
                tail.next = null;
                return returnVal;
            }else{
                int position = 0;
                Node<E> currentNode = head;

                while(position < index-1){
                    position++;
                    currentNode = currentNode.next;
                }

                E returnVal = currentNode.next.data;
                currentNode.next = currentNode.next.next;
                currentNode.next.prev = currentNode;
                return returnVal;
            }
        }else{
            throw new IndexOutOfBoundsException("Unable to remove");
        }
    }

    @Override
    public boolean remove(Object o){
        int index = indexOf(o);
        if(index == -1){
            return false;
        }else{
            remove(index);
            return true;
        }
    }

    @Override
    public int size(){
        int size = 0;
        Node<E> currentNode = head;
        while(currentNode != null){
            size += 1;
            currentNode = currentNode.next;
        }
        return size;
    }

    public String getFormatDataForward(){
        String output = "";
        Node<E> currentNode = head;
        while(currentNode != null){
            output += currentNode.data.toString();
            if(currentNode.next != null){
                output += " ";
            }
            currentNode = currentNode.next;
        }
        //TO DO: ADD CODE HERE

        return output;
    }

    public String getFormatDataBackward(){
        String output = "";
        Node<E> currentNode = tail;
        while(currentNode != null){
            output += currentNode.data.toString();
            if(currentNode.prev != null){
                output += " ";
            }
            currentNode = currentNode.prev;
        }

        //TO DO: ADD CODE HERE

        return output;
    }

    private class Node<E>{
        E data;
        Node<E> next;
        Node<E> prev;

        Node(E data){
            this.data = data;
            next = null;
            prev = null;
        }
    }
}
