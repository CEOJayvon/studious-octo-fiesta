[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Z-XAD-XU)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=18101857)
# Iterating Over a Linked List

The goal of this assignment is to iterate over the Doubly Linked List we created. You are to create two functions that will call the `toString()` of the `Node.data` and format a string where the data is separated with a space.

## Process

In the `src/org/csu/cpsc/MyDoublyLinkedList`, the `MyDoublyLinkedList` class is found. We created this during our lecture. I have added two new methods that you need to complete. 

1. On line 196 is `public String getFormatDataForward()`. You are to complete the function by going forward through the Linked list, starting with the head, and concatenating the `data.toString()` for each node together separated with a space. 
1. On line 204 is `public String getFormatDataBackward()`. You are to complete the function by going backward through the Linked list, starting with the tail, and concatenating the `data.toString()` for each node together separated with a space.


In the `Main.java`, I have provided a test for you to use and the desired output for each case. There are also test cases that will automatically be run when you push the code. If implemented correctly, the test cases should pass. If they fail, and you don't understand why, please email me. Failing test cases does not mean you failed the assignment.


