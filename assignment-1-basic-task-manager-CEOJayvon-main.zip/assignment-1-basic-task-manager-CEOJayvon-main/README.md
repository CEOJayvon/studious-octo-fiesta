[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/5zpsgT6G)
# Programming Project 0: Task List

In this programming project you will create a basic task list that we will build on a revisit throughout the semester. To begin we will create a Task object that will be used in an array in our Task Manager. The goal of this assignment is to review the Java programming language including creating classes, using variables, creating functions, using arrays, loops, and if statements by completing the accessors and mutators for the `Task` class and implementing the `TaskManagerInterface` in a `TaskManager` class. 

## Provided Files
In `src\main\java\org\csu\cpsc` you will find the source files that you will be modifying. 
* `Main` contains the main function for the Task Manager. In this class you will create a demo Task Manager and show the functions work
* `Task` contains the Task class. This holds the attributes of a task. 
* `TaskManagerInterface` contains the interface for the Task Manager Class. It outlines all the functionality the Task Class is to have.
* `TaskManager` contain the Task Manager class that implements the task interface.

## Instructions
This section will provide you step-by-step instructions on how to complete the assignment. 
1. Complete the `Task` class. The class has been started. You need to add accessors and mutators for each of the class variables.
   1. Add a `getName` function that returns the `String name` value.
   2. Add a `getOriginalDuration` function that returns the `int originalDuration` value.
   3. Add a `getDescription` function that returns the `String description` value.
   4. Add a `getTimeLogged` function that returns the `int timeLogged` value.
   5. Add a `setName` function that sets the `String name` value to the value passed in the function. 
   6. Add a `setOriginalDuration` function that sets the `int originalDuration` value to the value passed in the function.
   7. Add a `setDescription` function that sets the `String description` value to the value passed in the function.
   8. Add a `setTimeLogged` function. This function would work a little different that the previous ones. Instead of setting the `timeLogged` variable to the value in the function parameters, you will add the value in the function parameters to the `timeLogged` variable. For example, if `timeLogged = 1` and I call `setTimeLogged(3)`, the new value of `timeLogged` would be 4.
2. Complete the `TaskManager` class.
   1. Create private array of `Task` objects as a class variable
   2. Create a constructor that initializes the array to 5 tasks. The tasks should be null.
   3. Implement the `boolean addTask(Task task);` function. The goal of this function is to add the `task` to the array. You may use whatever method for managing the array you would like. When considering your method, remember you will also need to be able to remove tasks. I propose using a loop to find the next empty spot in the array and placing the task there. The psuedo-code for this solution would be:
   ```
   for i = 0, i < array.length, i++
       if array[i] == null
          array[i] = task
          return true
   return false
   ```
   4. Implement the `public Task removeTask(int index)` function. The goal of this function is to remove a task at a given index. Based on the array management strategy outlined in the `addTask`, to remove a task, save the task to a temporary variable, set the spot in the array to null, and return the task stored in the temporary variable. Psuedo-code for this solution would be
    ```
   Task temp = array[index]
   array[index] = null
   return temp
   ```
   5. Implement the `public String printTaskList()` function. The goal of this function is to print the tasks in the array, with their index values. This allows the users to know what task is at which index for updating and removing the tasks. Sample output would be:
   ```
   0. Task Name 
   1. Task Name
   ...
   ```
   6. Implement the `public String printTaskListDetailed()` function. The goal of this function is to print the details of each task in the array. Using a for loop, iterate over the array and print each task. 
   7. Implement the `public boolean updateTaskTimeLogged(int index, int time)` function. The goal of this function is add to the time logged on the task. 

3. Complete testing in the `Main`.
In the main, we want to test each of the functions that have been written. 
   1. First, test the `Task` class. Create a Task and call the toString. (We wrote this in class). For each variable, call the mutator to change the value in the Task, and then print the output of calling the accessor to show it changed. 
   2. Create a `TaskManager` object. Add 6 tasks to the TaskManager, printing the output of the addTask function. The last task you add should return false. 
   3. Print the tasks using the printTaskList() function. Note, if you get an error here for a null pointer exception, you will need to update the printTaskListDetailed to only print the value if it's not null.
   4. Remove task at index 2.
   5. Print the tasks using the printTaskList() function. Note, if you get an error here for a null pointer exception, you will need to update the printTaskListDetailed to only print the value if it's not null.
   6. Log time for task at index 1.
   7. Print the tasks using the printTaskListDetailed function. Note, if you get an error here for a null pointer exception, you will need to update the printTaskListDetailed to only print the value if it's not null.

## Deliverables
This assignment is due Tuesday, January 14 @ 11:59 PM. There are 2 deliverables:
1. Your code is to be pushed to your `main` branch in Github. Only code in the `main` branch will be grade. 
2. In Cougarview, please submit a document containing screenshots of your program running and a link to the Github repo.
