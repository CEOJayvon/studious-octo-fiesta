package org.csu.cpsc;

public interface TaskManagerInterface {
    boolean addTask(Task task);
    Task removeTask(int index);
    String printTaskList();
    String printTaskListDetailed();
    boolean updateTaskTimeLogged(int index, int time);
}
