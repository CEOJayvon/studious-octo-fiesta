package org.csu.cpsc;

public class Main {
    public static void main(String[] args) {
        Task t1 = new Task("Homework \n", 30, "Do the math homework assigned \n");

        System.out.println(t1.toString());
        t1.setDescription("Do the math homework assigned");
        t1.setTimeLogged(45);

        System.out.println("Description: " + t1.getDescription());
        System.out.println("Timelogged: " + t1.getTimeLogged() + " minutes \n");

        System.out.println("updated task: \n");
        System.out.println(t1.toString());



        TaskManager manager = new TaskManager();

        Task t2 = new Task("Dishes \n", 30, "Wash the dishes \n");
        Task t3 = new Task("Prep for class \n", 90, "Prep for Data Structures \n");
        Task t4 = new Task("Clothes \n", 45, "Iron the church clothes \n");
        Task t5 = new Task("Dogs \n", 50, "Feed the dogs and give them water \n");
        Task t6 = new Task("Floor \n", 90, "Sweep and mop the floors \n");
        
        System.out.println(manager.addTask(t1));
        System.out.println(manager.addTask(t2));
        System.out.println(manager.addTask(t3));
        System.out.println(manager.addTask(t4));
        System.out.println(manager.addTask(t5));
        System.out.println(manager.addTask(t6));

        System.out.println("updated task list ");
        System.out.println(manager.printTaskList());
        
        manager.removeTask(2);

       System.out.println(manager.printTaskList());

       manager.updateTaskTimeLogged(1,30 );

       System.out.println(manager.printTaskListDetailed());
    }

}