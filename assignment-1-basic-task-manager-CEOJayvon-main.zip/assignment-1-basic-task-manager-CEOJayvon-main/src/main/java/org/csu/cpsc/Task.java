package org.csu.cpsc;

public class Task {
    private String name;
    private int originalDuration;
    private String description;
    private int timeLogged;

    public Task(String name, int originalDuration, String description){
        this.name = name;
        this.originalDuration = originalDuration;
        this.description = description;
        this.timeLogged = 0;
    }

    //Accessors and Mutators

    public String toString(){
        return "Name: " + name + "\nDescription: " + description + "\nOriginal Estimate: " + originalDuration + "\nTime Logged: " + timeLogged;
    }

    public String getName(){
        return this.name;
    }
    public int getOriginalDuration(){
        return this.originalDuration;
    }
    public String getDescription(){
        return this.description;
    }
    public int getTimeLogged(){
        return this.timeLogged;
    }
    public String setName(String name){
        return this.name;
    }
    public int setOriginalDuration(int originalDuration){
        return this.originalDuration;
    }
    public String setDescription(String description){
        return this.description;
    }
    public void setTimeLogged(int timeLogged){
         this.timeLogged += timeLogged;
    }
}
