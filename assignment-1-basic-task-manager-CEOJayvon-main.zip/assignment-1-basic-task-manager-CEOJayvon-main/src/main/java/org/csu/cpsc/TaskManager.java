package org.csu.cpsc;

public class TaskManager implements TaskManagerInterface{



    @Override
    public boolean addTask(Task task) {
        for (int i = 0; i < tasks.length; i++){
            if(tasks[i]==null){
                tasks[i] = task;
                return true;
            }
        }
        //change this return value
        return false;
    }

    @Override
    public Task removeTask(int index) {
        if(index >= 0 && index < tasks.length && tasks[index] != null){
            tasks[index] = null;
        }
        return null;
        //change this return value
    
    }

    @Override
    public String printTaskList() {
        StringBuilder taskList = new StringBuilder();
        for (int i = 0; i < tasks.length; i++){
            if(tasks[i] != null){
                taskList.append("Index").append(":").append(tasks[i]);
            }
        }
        return taskList.toString();
        //change this return value
    }

    @Override
    public String printTaskListDetailed() {
        StringBuilder detailedList = new StringBuilder();
        for (int i = 0; i < tasks.length; i++){
            if (tasks[i] != null){
                detailedList.append("details about the task").append(i).append(":\n");
                detailedList.append(tasks[i].toString());
            }
        }
        //change this return value
        return detailedList.toString();
    }

    @Override
    public boolean updateTaskTimeLogged(int index, int time) {
        if(index >= 0 && index < tasks.length && tasks[index] != null){
            tasks[index].setTimeLogged(time);
            return true;
        }
        //change this return value
        return false;
    }
    private Task[] tasks;

    public TaskManager(){
        tasks = new Task[5];
    }
    

}
