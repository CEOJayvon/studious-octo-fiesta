import java.util.*;
public class User {
    String username;
    List<Message> inbox;
    Stack<Message> sentMessages;
    Queue<Message> notificationQueue;

    public User(String username) {
        this.username = username;
        this.inbox = new ArrayList<>();
        this.sentMessages = new Stack<>();
        this.notificationQueue = new LinkedList<>();
    }

    public void sendMessage(User receiver, String content) {
        Message msg = new Message(this.username, content);
        receiver.inbox.add(msg);
        receiver.notificationQueue.add(msg);
        this.sentMessages.push(msg);
        System.out.println("Message sent.");
    }

    public void undoLastMessage(User receiver) {
        if (!sentMessages.isEmpty()) {
            Message last = sentMessages.pop();
            receiver.inbox.remove(last);
            receiver.notificationQueue.remove(last);
            System.out.println("Last message undone.");
        } else {
            System.out.println("No message to undo.");
        }
    }

    public void viewInbox() {
        if (inbox.isEmpty()) {
            System.out.println("Inbox is empty.");
        } else {
            for (Message msg : inbox) {
                System.out.println(msg);
            }
        }
    }

    public void viewNotifications() {
        if (notificationQueue.isEmpty()) {
            System.out.println("No new notifications.");
        } else {
            while (!notificationQueue.isEmpty()) {
                System.out.println("Notification: " + notificationQueue.poll());
            }
        }
    }

    public void sortInbox() {
        for (int i = 0; i < inbox.size() - 1; i++) {
            for (int j = 0; j < inbox.size() - i - 1; j++) {
                if (inbox.get(j).timestamp > inbox.get(j + 1).timestamp) {
                    Collections.swap(inbox, j, j + 1);
                }
            }
        }
        System.out.println("Inbox sorted by time.");
    }
}
 

