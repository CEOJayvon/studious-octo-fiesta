import java.util.*;

// Custom class to represent a message
class Message {
    String sender;
    String content;
    long timestamp;

    Message(String sender, String content) {
        this.sender = sender;
        this.content = content;
        this.timestamp = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return sender + ": " + content + " (" + new Date(timestamp) + ")";
    }
}




