import java.util.*;

public class TikTokMessagingApp {
    Map<String, User> users = new HashMap<>();
    Scanner scanner = new Scanner(System.in);
    User currentUser = null;

    public static void main(String[] args) {
        new TikTokMessagingApp().run();
    }

    public void run() {
        System.out.println("Welcome to TikTok Messaging App!");

        while (true) {
            System.out.println("\n Main Menu");
            System.out.println("1. Register or Switch User");
            System.out.println("2. Send Message");
            System.out.println("3. Undo Last Message");
            System.out.println("4. View Inbox");
            System.out.println("5. View Notifications");
            System.out.println("6. Sort Inbox");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1": registerOrSwitchUser(); break;
                case "2": sendMessage(); break;
                case "3": undoMessage(); break;
                case "4": viewInbox(); break;
                case "5": viewNotifications(); break;
                case "6": sortInbox(); break;
                case "7": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private void registerOrSwitchUser() {
        System.out.print("Enter username: ");
        String name = scanner.nextLine();
        users.putIfAbsent(name, new User(name));
        currentUser = users.get(name);
        System.out.println("Logged in as: " + currentUser.username);
    }

    private void sendMessage() {
        if (checkCurrentUser()) return;

        System.out.print("Enter recipient username: ");
        String recipientName = scanner.nextLine();
        if (!users.containsKey(recipientName)) {
            System.out.println("User not found. Please register first.");
            return;
        }

        System.out.print("Enter message: ");
        String message = scanner.nextLine();
        currentUser.sendMessage(users.get(recipientName), message);
    }

    private void undoMessage() {
        if (checkCurrentUser()) return;

        System.out.print("Enter recipient username: ");
        String recipientName = scanner.nextLine();
        if (!users.containsKey(recipientName)) {
            System.out.println("User not found.");
            return;
        }

        currentUser.undoLastMessage(users.get(recipientName));
    }

    private void viewInbox() {
        if (checkCurrentUser()) return;
        currentUser.viewInbox();
    }

    private void viewNotifications() {
        if (checkCurrentUser()) return;
        currentUser.viewNotifications();
    }

    private void sortInbox() {
        if (checkCurrentUser()) return;
        currentUser.sortInbox();
    }

    private boolean checkCurrentUser() {
        if (currentUser == null) {
            System.out.println("Please log in first.");
            return true;
        }
        return false;
    }
}
